X3D Is a simple 3D Engine.  It uses GDI32 for its API.
This is to quickly draw polygons.  I am working on textures for it.
First compile the project titled Final Engine 1.o.  
Then go into the test folder and run The test program.
It demonstrates how to use the X3D Engine.  Also, your polygons must be
traingles.  Any points after Point2 will be ignored.